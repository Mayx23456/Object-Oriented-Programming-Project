package Part1;

import java.util.ArrayList;

public class Library {

	private ArrayList <LibraryBook> books;
	
	Library()
	{
		this.books = new ArrayList<LibraryBook>();
		
	}
	
	Boolean borrowBook(int id)
	{
		if(status != BookStatus.ON_LOAN)
		{
			
		}
	}
	
	Boolean returnBook(int id)
	{
		
	}
	
	
	
	
	
}

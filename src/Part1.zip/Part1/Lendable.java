package Part1;

public interface Lendable {

	boolean checkout();
	boolean checkin();
	
	
}

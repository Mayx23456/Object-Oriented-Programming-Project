package Part1;

public class LibraryBook extends Book implements Lendable {

    private int id;
    private static int nextId;
    private BookStatus status;
    private String image;
    private int loanCount;
    private String coverImage;

    
    LibraryBook(int nextId, BookStatus status, String coverImage, int loanCount, String title, String author, String isbn, BookType type, int edition, String summary, double price, String image) {
        super(title, author, isbn, type, edition, summary, price);
        this.id = nextId;
        this.status = status;
        this.coverImage = coverImage; 
        this.loanCount = loanCount;
        this.image = image; 
    }


    public void setStatus(BookStatus status) {
        this.status = status;
    }

    public BookStatus getStatus() {
        return status;
    }

    @Override
    public boolean checkout() {
        if(status == BookStatus.AVAILABLE)
        {
        	status = BookStatus.ON_LOAN;
        	loanCount++;
        	return true;
        }
        return false;
    }

    @Override
    public boolean checkin() {
        if(status == BookStatus.ON_LOAN )
        {
        	status = BookStatus.AVAILABLE;
        	return true;
        }
        return false;
    }
    
    @Override
    public String toString() {
        return "LibraryBook{" +
                "id=" + id +
                ", title='" + getTitle() + '\'' +
                ", status=" + status +
                ", loanCount=" + loanCount +
                '}';
    }
}
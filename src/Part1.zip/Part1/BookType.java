package Part1;

public enum BookType {

	FICTION, NON_FICTION,REFERENCE;
}

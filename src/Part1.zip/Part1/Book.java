package Part1;

public class Book {
    private String title;
    private String author;
    private String isbn;
    private BookType type;
    private int edition;
    private String summary;
    private double price;

    public Book(String title, String author, String isbn, BookType type, int edition, String summary, double price) {
        if (title.length() >= 5 && title.length() <= 40) {
            this.title = title;
        }
        if (author.length() >= 5 && author.length() <= 40) {
            this.author = author;
        }
        
        if (isbn != null && isbn.matches("\\d{10}")) {
            this.isbn = isbn;
        } else {
            throw new IllegalArgumentException("ISBN must be exactly 10 digits.");
        }
        
        this.type = type;
        this.edition = edition; 
        
        if (summary.length() >= 20 && summary.length() <= 150) {
            this.summary = summary;
        }
        this.price = price;
    }

    // Getter and Setter for title
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        if (title.length() >= 5 && title.length() <= 40) {
            this.title = title;
        }
    }

    // Getter and Setter for author
    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        if (author.length() >= 5 && author.length() <= 40) {
            this.author = author;
        }
    }

    // Getter and Setter for ISBN 
    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        if (isbn != null && isbn.matches("\\d{10}")) { // Ensures exactly 10 digits
            this.isbn = isbn;
        } else {
            throw new IllegalArgumentException("ISBN must be exactly 10 digits.");
        }
    }

    // Getter and Setter for BookType
    public BookType getType() {
        return type;
    }

    public void setType(BookType type) {
        this.type = type;
    }

    // Getter and Setter for edition
    public int getEdition() {
        return edition;
    }

    public void setEdition(int edition) {
        this.edition = edition;
    }

    // Getter and Setter for summary
    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        if (summary.length() >= 20 && summary.length() <= 150) {
            this.summary = summary;
        }
    }

    // Getter and Setter for price
    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

   
    @Override
    public String toString() {
        return "Title: " + title + ", " +
               "Author: " + author + ", " +
               "ISBN: " + isbn + ", " +
               "Status: " + type + ", " +
               "Edition: " + edition + ", " +
               "Summary: " + summary + ", " +
               String.format("£%.2f", price); 
    }
}
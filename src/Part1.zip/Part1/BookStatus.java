package Part1;

public enum BookStatus {

	AVAILABLE, ON_LOAN, WITHDRAW;
}
